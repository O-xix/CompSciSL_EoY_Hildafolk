package com.computerscience;
import java.awt.*;
import java.io.*;
import java.lang.*;
import java.net.*;
import java.util.*;
import javax.imageio.*;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        System.out.println("");
        DrawingPanel panel = new DrawingPanel(960, 540);
        int posXpos = 0;
        int posYpos = 0;
        redMage pafie = new redMage();
        //redMage chara1 = pafie;
        pafie.redMageSpriteRefresh(panel, posXpos, posYpos);
    }
    /*
    public static void garlandBattle(){
        boolean garlandDefeated = False;
        for (garlandedDefeated != True){

        }
    }
     */
}
class redMage {
    //Stats and other variables:
    String redMageName = "Pafie";

    int redMageHP = 0;
    int redMageMaxHP = 0;

    int redMageMP = 0;
    int redMageMaxMP = 0;

    int redMageStrength = 0;
    int redMageAgility = 0;
    int redMageIntelligence = 0;
    int redMageStamina = 0;
    int redMageLuck = 0;

    int redMageAttack = 0;
    int redMageAccuracy = 0;
    int redMageDefense = 0;
    int redMageEvasion = 0;


    public void redMageSpriteRefresh(DrawingPanel panel, int redMageXPos, int redMageYPos) {
        Graphics redMageSprite = panel.getGraphics();
        //Making the sprite:
        //g.setColor(new Color(0, 0, 0)); RGB Coloring
        //g.fillRect(x, y, width, height);
        //Black portion of the sprite:
        redMageSprite.setColor(new Color(0, 0, 0));
        //Column 1 of Sprite (x = 5)
        redMageSprite.fillRect(5 + redMageXPos, 35 + redMageYPos, 5, 10);
        redMageSprite.fillRect(5 + redMageXPos, 73 + redMageYPos, 5, 15);
    }
}
class spellBlade extends redMage {

    public void spellBladeSpriteRefresh(DrawingPanel panel, int spellBladeXPos, int spellBladeYPos) {
        Graphics spellBladeSprite = panel.getGraphics();
        //Making the sprite:
        //g.setColor(new Color(0, 0, 0)); RGB Coloring
        //g.fillRect(x, y, width, height);
        //Black portion of the sprite:
        spellBladeSprite.setColor(new Color(0, 0, 0));
        //Column 1 of Sprite (x = 5)
        spellBladeSprite.fillRect(5 + spellBladeXPos, 35 + spellBladeYPos, 5, 10);
        spellBladeSprite.fillRect(5 + spellBladeXPos, 72 + spellBladeYPos, 5, 15);
    }
}